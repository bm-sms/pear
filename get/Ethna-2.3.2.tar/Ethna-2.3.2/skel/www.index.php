<?php
require_once '{$basedir}/app/{$project_id}_Controller.php';

{$project_id}_Controller::main('{$project_id}_Controller', 'index');
?>
