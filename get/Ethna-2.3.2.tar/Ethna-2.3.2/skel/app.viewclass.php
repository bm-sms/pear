<?php
// vim: foldmethod=marker
/**
 *  {$project_id}_ViewClass.php
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @version    $Id$
 */

// {{{ {$project_id}_ViewClass
/**
 *  viewクラス
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @access     public
 */
class {$project_id}_ViewClass extends Ethna_ViewClass
{
    /**
     *  共通値を設定する
     *
     *  @access protected
     *  @param  object  {$project_id}_Renderer  レンダラオブジェクト
     */
    function _setDefault(&$renderer)
    {
    }
}
// }}}
?>
