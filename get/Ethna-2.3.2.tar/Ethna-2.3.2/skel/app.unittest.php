<?php
/**
 *  {$project_id}_UnitTestManager.php
 *
 *  @author     {$author}
 *  @package    {$project_id}
 *  @version    $Id$
 */

/**
 *  {$project_id}ユニットテストマネージャクラス
 *
 *  @author     {$author}
 *  @access     public
 *  @package    {$project_id}
 */
class {$project_id}_UnitTestManager extends Ethna_UnitTestManager
{
    /**
     *  @var    array   一般テストケース定義
     */
    var $testcase = array(
        /*
         *  TODO: ここに一般テストケース定義を記述してください
         *
         *  記述例：
         *
         *  'util' => 'app/UtilTest.php',
         */
    );
}
?>
